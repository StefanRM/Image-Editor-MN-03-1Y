function value = trilerp(stack, row, col, level)
    % Folositi interpolarea triliniara pentru a estima intensitatea unei
    % imagini in pozitia row, col, level.

    %TODO
end
